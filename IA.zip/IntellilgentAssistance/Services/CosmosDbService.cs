using Microsoft.Azure.Cosmos;
using IntellilgentAssistance.Models;

namespace IntellilgentAssistance.Services;

public interface ICosmosDbService
{
    Task<IEnumerable<ChatMessage>> GetChatHistoryAsync(string sessionId);
    Task AddMessageAsync(ChatMessage message);
}

public class CosmosDbService : ICosmosDbService
{
    private readonly Container _container;

    public CosmosDbService(CosmosClient cosmosClient, string databaseName, string containerName)
    {
        _container = cosmosClient.GetContainer(databaseName, containerName);
    }

    public async Task<IEnumerable<ChatMessage>> GetChatHistoryAsync(string sessionId)
    {
        var query = _container.GetItemQueryIterator<ChatMessage>(
            new QueryDefinition("SELECT * FROM c WHERE c.sessionId = @sessionId ORDER BY c.timestamp")
            .WithParameter("@sessionId", sessionId));

        var results = new List<ChatMessage>();
        while (query.HasMoreResults)
        {
            var response = await query.ReadNextAsync();
            results.AddRange(response.ToList());
        }

        return results;
    }

    public async Task AddMessageAsync(ChatMessage message)
    {
        await _container.CreateItemAsync(message, new PartitionKey(message.SessionId));
    }
} 