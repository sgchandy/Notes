using Azure.Core;
using IntellilgentAssistance.Services;

namespace IntellilgentAssistance.Services;

public class TokenCredentials : TokenCredential
{
    private readonly ITokenService _tokenService;

    public TokenCredentials(ITokenService tokenService)
    {
        _tokenService = tokenService;
    }

    public override AccessToken GetToken(TokenRequestContext requestContext, CancellationToken cancellationToken)
    {
        var token = _tokenService.GetAccessTokenAsync().GetAwaiter().GetResult();
        return new AccessToken(token, DateTimeOffset.UtcNow.AddHours(1));
    }

    public override ValueTask<AccessToken> GetTokenAsync(TokenRequestContext requestContext, CancellationToken cancellationToken)
    {
        return new ValueTask<AccessToken>(GetToken(requestContext, cancellationToken));
    }
} 