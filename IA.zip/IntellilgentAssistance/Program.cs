using Azure.AI.OpenAI;
using Azure.Monitor.OpenTelemetry.Exporter;
using Microsoft.Azure.Cosmos;
using Microsoft.OpenApi.Models;
using Microsoft.SemanticKernel;
using OpenTelemetry.Metrics;
using OpenTelemetry.Resources;
using OpenTelemetry.Trace;
using IntellilgentAssistance.Services;
using System.Diagnostics;

var builder = WebApplication.CreateBuilder(args);

// Configure CORS
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowSpecificOrigins",
        policy => policy
            .WithOrigins("your-allowed-origins")
            .AllowAnyMethod()
            .AllowAnyHeader()
            .AllowCredentials());
});

// Add services to the container.
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();

// Configure Swagger
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo { Title = "Intelligent Assistant API", Version = "v1" });
});

// Configure CosmosDB with connection string
builder.Services.AddSingleton<IChatHistoryService>(sp =>
{
    var cosmosClient = new CosmosClient(
        builder.Configuration["CosmosDb:Account"],
        builder.Configuration["CosmosDb:Key"]);

    var database = cosmosClient.CreateDatabaseIfNotExistsAsync(
        builder.Configuration["CosmosDb:DatabaseName"]).GetAwaiter().GetResult();

    database.Database.CreateContainerIfNotExistsAsync(
        builder.Configuration["CosmosDb:ContainerName"],
        "/sessionId").GetAwaiter().GetResult();

    return new ChatHistoryService(
        cosmosClient,
        builder.Configuration["CosmosDb:DatabaseName"] ?? throw new ArgumentNullException("CosmosDb:DatabaseName"),
        builder.Configuration["CosmosDb:ContainerName"] ?? throw new ArgumentNullException("CosmosDb:ContainerName"));
});

// Add TokenService
builder.Services.AddSingleton<ITokenService, TokenService>();

// Configure Semantic Kernel with Azure OpenAI using OAuth
builder.Services.AddSingleton<Kernel>(sp =>
{
    var tokenService = sp.GetRequiredService<ITokenService>();
    
    var kernelBuilder = Kernel.CreateBuilder()
        .AddAzureOpenAIChatCompletion(
            deploymentName: builder.Configuration["AzureOpenAI:DeploymentName"] ?? throw new ArgumentNullException("AzureOpenAI:DeploymentName"),
            endpoint: builder.Configuration["AzureOpenAI:Endpoint"] ?? throw new ArgumentNullException("AzureOpenAI:Endpoint"),
            credentials: new TokenCredentials(tokenService));

    return kernelBuilder.Build();
});

// Add Application Insights
builder.Services.AddApplicationInsightsTelemetry();

// Configure OpenTelemetry
builder.Services.AddOpenTelemetry()
    .ConfigureResource(resource => resource
        .AddService(serviceName: "IntellilgentAssistance",
                   serviceVersion: "1.0.0"))
    .WithTracing(tracing => tracing
        .AddAspNetCoreInstrumentation()
        .AddHttpClientInstrumentation()
        .AddConsoleExporter()
        .AddAzureMonitorTraceExporter(o =>
        {
            o.ConnectionString = builder.Configuration["ApplicationInsights:ConnectionString"];
        }))
    .WithMetrics(metrics => metrics
        .AddAspNetCoreInstrumentation()
        .AddHttpClientInstrumentation()
        .AddRuntimeInstrumentation()
        .AddConsoleExporter()
        .AddAzureMonitorMetricExporter(o =>
        {
            o.ConnectionString = builder.Configuration["ApplicationInsights:ConnectionString"];
        }));

// Add custom activity source
builder.Services.AddSingleton(new ActivitySource("IntellilgentAssistance"));

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(c =>
    {
        c.SwaggerEndpoint("/swagger/v1/swagger.json", "Intelligent Assistant API V1");
    });
}

app.UseHttpsRedirection();
app.UseCors("AllowSpecificOrigins");

// Add middleware to enrich telemetry
app.Use(async (context, next) =>
{
    var activity = Activity.Current;
    if (activity != null)
    {
        activity.SetTag("request.path", context.Request.Path);
        activity.SetTag("request.method", context.Request.Method);
    }
    await next();
});

app.MapControllers();

app.Run();
