using Microsoft.AspNetCore.Mvc;
using Microsoft.SemanticKernel;
using Microsoft.SemanticKernel.ChatCompletion;
using IntellilgentAssistance.Models;
using IntellilgentAssistance.Services;
using System.Diagnostics;

namespace IntellilgentAssistance.Controllers;

[ApiController]
[Route("[controller]")]
public class ChatController : ControllerBase
{
    private readonly Kernel _kernel;
    private readonly ILogger<ChatController> _logger;
    private readonly IChatHistoryService _chatHistoryService;
    private readonly ActivitySource _activitySource;
    private readonly IChatCompletionService _chatCompletionService;

    public ChatController(
        Kernel kernel,
        ILogger<ChatController> logger,
        IChatHistoryService chatHistoryService,
        ActivitySource activitySource)
    {
        _kernel = kernel;
        _logger = logger;
        _chatHistoryService = chatHistoryService;
        _activitySource = activitySource;
        _chatCompletionService = kernel.GetRequiredService<IChatCompletionService>();
    }

    [HttpPost("session")]
    public async Task<IActionResult> CreateSession()
    {
        try
        {
            using var activity = _activitySource.StartActivity("CreateChatSession");

            var sessionId = await _chatHistoryService.CreateSessionAsync();
            activity?.SetTag("session.id", sessionId);

            return Ok(sessionId);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating chat session");
            Activity.Current?.SetStatus(ActivityStatusCode.Error, ex.Message);
            return StatusCode(500, "Error creating chat session");
        }
    }

    [HttpGet("history/{sessionId}")]
    public async Task<IActionResult> GetHistory(string sessionId)
    {
        try
        {
            using var activity = _activitySource.StartActivity("GetChatHistory");
            activity?.SetTag("session.id", sessionId);

            var messages = await _chatHistoryService.GetChatHistoryAsync(sessionId);
            activity?.SetTag("message.count", messages.Count());

            return Ok(messages);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving chat history for session {SessionId}", sessionId);
            Activity.Current?.SetStatus(ActivityStatusCode.Error, ex.Message);
            return StatusCode(500, "Error retrieving chat history");
        }
    }

    [HttpPost]
    public async Task<IActionResult> Chat([FromBody] ChatRequest request)
    {
        try
        {
            using var activity = _activitySource.StartActivity("ProcessChatMessage");
            activity?.SetTag("session.id", request.SessionId);
            activity?.SetTag("message.length", request.Prompt.Length);

            var messages = await _chatHistoryService.GetChatHistoryAsync(request.SessionId);

            var stopwatch = Stopwatch.StartNew();
            
            // Save user message
            await _chatHistoryService.SaveMessageAsync(new ChatMessage
            {
                SessionId = request.SessionId,
                Role = "user",
                Content = request.Prompt
            });

            // Get AI response
            var chatHistory = new ChatHistory();
            foreach (var message in messages)
            {
                chatHistory.AddMessage(message.Role == "user" ? AuthorRole.User : AuthorRole.Assistant, message.Content);
            }

            var chatResult = await _chatCompletionService.GetChatMessageContentsAsync(
                chatHistory,
                executionSettings: null,
                kernel: _kernel,
                cancellationToken: CancellationToken.None
            );

            stopwatch.Stop();
            activity?.SetTag("response.time_ms", stopwatch.ElapsedMilliseconds);

            // Save assistant message
            await _chatHistoryService.SaveMessageAsync(new ChatMessage
            {
                SessionId = request.SessionId,
                Role = "assistant",
                Content = chatResult.First().Content,
                Timestamp = DateTime.UtcNow
            });

            return Ok(new { message = chatResult.First().Content });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error processing chat request for session {SessionId}", request.SessionId);
            Activity.Current?.SetStatus(ActivityStatusCode.Error, ex.Message);
            return StatusCode(500, "Error processing chat request");
        }
    }
} 