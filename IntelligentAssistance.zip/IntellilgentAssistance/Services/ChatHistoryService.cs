using Microsoft.Azure.Cosmos;
using IntellilgentAssistance.Models;

namespace IntellilgentAssistance.Services;

public interface IChatHistoryService
{
    Task<IEnumerable<ChatMessage>> GetChatHistoryAsync(string sessionId);
    Task SaveMessageAsync(ChatMessage message);
    Task<string> CreateSessionAsync();
}

public class ChatHistoryService : IChatHistoryService
{
    private readonly Container _container;

    public ChatHistoryService(CosmosClient cosmosClient, string databaseName, string containerName)
    {
        _container = cosmosClient.GetContainer(databaseName, containerName);
    }

    public async Task<IEnumerable<ChatMessage>> GetChatHistoryAsync(string sessionId)
    {
        var query = _container.GetItemQueryIterator<ChatMessage>(
            new QueryDefinition("SELECT * FROM c WHERE c.sessionId = @sessionId ORDER BY c.timestamp")
            .WithParameter("@sessionId", sessionId));

        var messages = new List<ChatMessage>();
        while (query.HasMoreResults)
        {
            var response = await query.ReadNextAsync();
            messages.AddRange(response.ToList());
        }

        return messages;
    }

    public async Task SaveMessageAsync(ChatMessage message)
    {
        await _container.CreateItemAsync(message, new PartitionKey(message.SessionId));
    }

    public Task<string> CreateSessionAsync()
    {
        return Task.FromResult(Guid.NewGuid().ToString());
    }
} 