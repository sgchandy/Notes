using System.Net.Http.Headers;
using System.Text.Json;

namespace IntellilgentAssistance.Services;

public interface ITokenService
{
    Task<string> GetAccessTokenAsync();
}

public class TokenService : ITokenService
{
    private readonly IConfiguration _configuration;
    private readonly HttpClient _httpClient;
    private string? _cachedToken;
    private DateTime _tokenExpiration = DateTime.MinValue;

    public TokenService(IConfiguration configuration)
    {
        _configuration = configuration;
        _httpClient = new HttpClient();
    }

    public async Task<string> GetAccessTokenAsync()
    {
        if (_cachedToken != null && DateTime.UtcNow < _tokenExpiration)
        {
            return _cachedToken;
        }

        var tokenEndpoint = _configuration["AzureOpenAI:AuthEndpoint"];
        var clientId = _configuration["AzureOpenAI:ClientId"];
        var clientSecret = _configuration["AzureOpenAI:ClientSecret"];
        var scope = _configuration["AzureOpenAI:Scope"];

        var content = new FormUrlEncodedContent(new[]
        {
            new KeyValuePair<string, string>("grant_type", "client_credentials"),
            new KeyValuePair<string, string>("client_id", clientId!),
            new KeyValuePair<string, string>("client_secret", clientSecret!),
            new KeyValuePair<string, string>("scope", scope!)
        });

        var response = await _httpClient.PostAsync(tokenEndpoint, content);
        response.EnsureSuccessStatusCode();

        var jsonResponse = await response.Content.ReadAsStringAsync();
        var tokenResponse = JsonSerializer.Deserialize<JsonElement>(jsonResponse);

        _cachedToken = tokenResponse.GetProperty("access_token").GetString();
        var expiresIn = tokenResponse.GetProperty("expires_in").GetInt32();
        _tokenExpiration = DateTime.UtcNow.AddSeconds(expiresIn - 300); // Refresh 5 minutes before expiration

        return _cachedToken!;
    }
} 