namespace IntellilgentAssistance.Models;

public class ChatRequest
{
    public string SessionId { get; set; } = Guid.NewGuid().ToString();
    public string Prompt { get; set; } = string.Empty;
} 