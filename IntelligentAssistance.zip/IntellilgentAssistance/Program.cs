using Azure.AI.OpenAI;
using Azure.Monitor.OpenTelemetry.Exporter;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.Azure.Cosmos;
using Microsoft.Identity.Web;
using Microsoft.OpenApi.Models;
using Microsoft.SemanticKernel;
using OpenTelemetry.Metrics;
using OpenTelemetry.Resources;
using OpenTelemetry.Trace;
using IntellilgentAssistance.Services;
using System.Diagnostics;
using System.Security.Claims;

var builder = WebApplication.CreateBuilder(args);

// Add Azure AD authentication
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddMicrosoftIdentityWebApi(options =>
    {
        builder.Configuration.Bind("AzureAd", options);
        options.TokenValidationParameters.ValidateIssuer = true;
        options.TokenValidationParameters.ValidateAudience = true;
    }, options => builder.Configuration.Bind("AzureAd", options));

// Add authorization policies
builder.Services.AddAuthorization(options =>
{
    options.AddPolicy("RequireAuthenticatedUser", policy =>
        policy.RequireAuthenticatedUser());
});

// Configure CORS
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowSpecificOrigins",
        policy => policy
            .WithOrigins("your-allowed-origins")
            .AllowAnyMethod()
            .AllowAnyHeader()
            .AllowCredentials());
});

// Add services to the container.
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();

// Configure Swagger with OAuth
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo { Title = "Semantic Kernel API", Version = "v1" });
    c.AddSecurityDefinition("oauth2", new OpenApiSecurityScheme
    {
        Type = SecuritySchemeType.OAuth2,
        Flows = new OpenApiOAuthFlows
        {
            AuthorizationCode = new OpenApiOAuthFlow
            {
                AuthorizationUrl = new Uri($"https://login.microsoftonline.com/{builder.Configuration["AzureAd:TenantId"]}/oauth2/v2.0/authorize"),
                TokenUrl = new Uri($"https://login.microsoftonline.com/{builder.Configuration["AzureAd:TenantId"]}/oauth2/v2.0/token"),
                Scopes = new Dictionary<string, string>
                {
                    { "api://your-client-id/access_as_user", "Access as user" }
                }
            }
        }
    });
    c.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
            {
                Reference = new OpenApiReference { Type = ReferenceType.SecurityScheme, Id = "oauth2" }
            },
            new[] { "api://your-client-id/access_as_user" }
        }
    });
});

// Configure CosmosDB with connection string
builder.Services.AddSingleton<IChatHistoryService>(sp =>
{
    var cosmosClient = new CosmosClient(
        builder.Configuration["CosmosDb:Account"],
        builder.Configuration["CosmosDb:Key"]);

    var database = cosmosClient.CreateDatabaseIfNotExistsAsync(
        builder.Configuration["CosmosDb:DatabaseName"]).GetAwaiter().GetResult();

    database.Database.CreateContainerIfNotExistsAsync(
        builder.Configuration["CosmosDb:ContainerName"],
        "/sessionId").GetAwaiter().GetResult();

    return new ChatHistoryService(
        cosmosClient,
        builder.Configuration["CosmosDb:DatabaseName"] ?? throw new ArgumentNullException("CosmosDb:DatabaseName"),
        builder.Configuration["CosmosDb:ContainerName"] ?? throw new ArgumentNullException("CosmosDb:ContainerName"));
});

// Add TokenService
builder.Services.AddSingleton<ITokenService, TokenService>();

// Configure Semantic Kernel with Azure OpenAI using OAuth
builder.Services.AddSingleton<Kernel>(sp =>
{
    var tokenService = sp.GetRequiredService<ITokenService>();
    
    var kernelBuilder = Kernel.CreateBuilder()
        .AddAzureOpenAIChatCompletion(
            deploymentName: builder.Configuration["AzureOpenAI:DeploymentName"] ?? throw new ArgumentNullException("AzureOpenAI:DeploymentName"),
            endpoint: builder.Configuration["AzureOpenAI:Endpoint"] ?? throw new ArgumentNullException("AzureOpenAI:Endpoint"),
            credentials: new TokenCredentials(tokenService));

    return kernelBuilder.Build();
});

// Add Application Insights
builder.Services.AddApplicationInsightsTelemetry();

// Configure OpenTelemetry
builder.Services.AddOpenTelemetry()
    .ConfigureResource(resource => resource
        .AddService(serviceName: "IntellilgentAssistance",
                   serviceVersion: "1.0.0"))
    .WithTracing(tracing => tracing
        .AddAspNetCoreInstrumentation()
        .AddHttpClientInstrumentation()
        .AddConsoleExporter()
        .AddAzureMonitorTraceExporter(o =>
        {
            o.ConnectionString = builder.Configuration["ApplicationInsights:ConnectionString"];
        }))
    .WithMetrics(metrics => metrics
        .AddAspNetCoreInstrumentation()
        .AddHttpClientInstrumentation()
        .AddRuntimeInstrumentation()
        .AddConsoleExporter()
        .AddAzureMonitorMetricExporter(o =>
        {
            o.ConnectionString = builder.Configuration["ApplicationInsights:ConnectionString"];
        }));

// Add custom activity source
builder.Services.AddSingleton(new ActivitySource("IntellilgentAssistance"));

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(c =>
    {
        c.SwaggerEndpoint("/swagger/v1/swagger.json", "Semantic Kernel API V1");
        c.OAuthClientId(builder.Configuration["AzureAd:ClientId"]);
        c.OAuthUsePkce();
    });
}

app.UseHttpsRedirection();
app.UseCors("AllowSpecificOrigins");
app.UseAuthentication();
app.UseAuthorization();

// Add middleware to enrich telemetry with user information
app.Use(async (context, next) =>
{
    if (context.User.Identity?.IsAuthenticated == true)
    {
        var activity = Activity.Current;
        if (activity != null)
        {
            activity.SetTag("user.id", context.User.FindFirst(ClaimTypes.NameIdentifier)?.Value);
            activity.SetTag("user.name", context.User.FindFirst(ClaimTypes.Name)?.Value);
        }
    }
    await next();
});

app.MapControllers();

app.Run();

// Add TokenCredentials class at the end of the file
public class TokenCredentials : Azure.Core.TokenCredential
{
    private readonly ITokenService _tokenService;

    public TokenCredentials(ITokenService tokenService)
    {
        _tokenService = tokenService;
    }

    public override Azure.Core.AccessToken GetToken(Azure.Core.TokenRequestContext requestContext, CancellationToken cancellationToken)
    {
        var token = _tokenService.GetAccessTokenAsync().GetAwaiter().GetResult();
        return new Azure.Core.AccessToken(token, DateTimeOffset.UtcNow.AddHours(1));
    }

    public override ValueTask<Azure.Core.AccessToken> GetTokenAsync(Azure.Core.TokenRequestContext requestContext, CancellationToken cancellationToken)
    {
        return new ValueTask<Azure.Core.AccessToken>(GetToken(requestContext, cancellationToken));
    }
}
